/**
 * Análisis de la URL contenida en el código QR de una factura Verifactu.
 *
 * Implementación de referencia. Sigue la especificación de la AEAT v0.5.0 (ver `fixtures/qr.json`).
 * Devuelve códigos de error legibles por máquina, para poder compararlos en una suite de CI.
 */

import { nifValido } from "./nif";

export type Entorno = "produccion" | "pruebas";
export type Sistema = "verificable" | "no-verificable";

/** Códigos de error. Son los mismos que aparecen en `fixtures/qr.json`. */
export type CodigoError =
  | "url-base-desconocida"
  | "numserie-sin-codificar"
  | "caracteres-no-imprimibles"
  | "falta-nif"
  | "falta-numserie"
  | "falta-fecha"
  | "falta-importe"
  | "nif-invalido"
  | "numserie-demasiado-largo"
  | "fecha-formato"
  | "fecha-inexistente"
  | "importe-formato"
  | "formato-prohibido-en-qr"
  | "idioma-invalido";

export const BASES: readonly { url: string; entorno: Entorno; sistema: Sistema }[] = [
  {
    url: "https://www2.agenciatributaria.gob.es/wlpl/TIKE-CONT/ValidarQR",
    entorno: "produccion",
    sistema: "verificable",
  },
  {
    url: "https://www2.agenciatributaria.gob.es/wlpl/TIKE-CONT/ValidarQRNoVerifactu",
    entorno: "produccion",
    sistema: "no-verificable",
  },
  {
    url: "https://prewww2.aeat.es/wlpl/TIKE-CONT/ValidarQR",
    entorno: "pruebas",
    sistema: "verificable",
  },
  {
    url: "https://prewww2.aeat.es/wlpl/TIKE-CONT/ValidarQRNoVerifactu",
    entorno: "pruebas",
    sistema: "no-verificable",
  },
] as const;

const OBLIGATORIOS = ["nif", "numserie", "fecha", "importe"] as const;
const OPCIONALES = ["idioma", "formato"] as const;
const CONOCIDOS = new Set<string>([...OBLIGATORIOS, ...OPCIONALES]);
const IDIOMAS = ["gl", "ca", "eu", "es", "va", "en"];

export type AnalisisQr = {
  valido: boolean;
  errores: CodigoError[];
  base: string | null;
  entorno: Entorno | null;
  sistema: Sistema | null;
  parametros: Record<string, string>;
  /** URL corregida, cuando los problemas se pueden arreglar sin inventarse datos. */
  urlCorregida: string | null;
};

function soloAsciiImprimible(valor: string): boolean {
  return [...valor].every((c) => {
    const code = c.codePointAt(0)!;
    return code >= 32 && code <= 126;
  });
}

function decodificar(valor: string): string {
  try {
    return decodeURIComponent(valor);
  } catch {
    return valor;
  }
}

/**
 * Trocea la query reagrupando los valores partidos por un `&` sin codificar.
 *
 * Este es el error estrella, y la propia AEAT lo publica como ejemplo de URL incorrecta: un `&`
 * dentro del número de serie parte la URL y crea un parámetro fantasma. Al reagrupar los trozos
 * podemos decir qué numserie se pretendía enviar y ofrecer la URL corregida.
 */
function trocear(query: string): { parametros: Record<string, string>; partida: boolean } {
  const parametros: Record<string, string> = {};
  const orden: string[] = [];
  let partida = false;

  for (const token of query.split("&")) {
    const eq = token.indexOf("=");
    const clave = eq === -1 ? "" : token.slice(0, eq).toLowerCase();

    if (eq !== -1 && CONOCIDOS.has(clave)) {
      parametros[clave] = token.slice(eq + 1);
      orden.push(clave);
      continue;
    }

    // No es un parámetro conocido: es la continuación del valor anterior, partido por un `&`
    // que debería haber ido codificado.
    const ultima = orden[orden.length - 1];
    if (ultima) {
      parametros[ultima] = `${parametros[ultima]}&${token}`;
      partida = true;
    }
  }

  return { parametros, partida };
}

export function analizarQr(bruto: string): AnalisisQr {
  const url = bruto.trim();
  const errores: CodigoError[] = [];

  const vacio: AnalisisQr = {
    valido: false,
    errores,
    base: null,
    entorno: null,
    sistema: null,
    parametros: {},
    urlCorregida: null,
  };

  if (!soloAsciiImprimible(url)) errores.push("caracteres-no-imprimibles");

  const inicio = url.indexOf("?");
  const base = inicio === -1 ? url : url.slice(0, inicio);
  const query = inicio === -1 ? "" : url.slice(inicio + 1);

  const conocida = BASES.find((b) => b.url.toLowerCase() === base.toLowerCase());
  if (!conocida) {
    errores.push("url-base-desconocida");
    return vacio;
  }

  const { parametros, partida } = trocear(query);
  if (partida) errores.push("numserie-sin-codificar");

  for (const nombre of OBLIGATORIOS) {
    if (parametros[nombre] === undefined) {
      errores.push(`falta-${nombre}` as CodigoError);
    }
  }

  if (parametros.formato !== undefined) errores.push("formato-prohibido-en-qr");

  if (parametros.idioma !== undefined && !IDIOMAS.includes(decodificar(parametros.idioma))) {
    errores.push("idioma-invalido");
  }

  if (parametros.nif !== undefined && !nifValido(decodificar(parametros.nif))) {
    errores.push("nif-invalido");
  }

  if (parametros.numserie !== undefined) {
    const valor = decodificar(parametros.numserie);
    if (valor.length > 60) errores.push("numserie-demasiado-largo");
  }

  if (parametros.fecha !== undefined) {
    const valor = decodificar(parametros.fecha);
    const m = /^(\d{2})-(\d{2})-(\d{4})$/.exec(valor);

    if (!m) {
      errores.push("fecha-formato");
    } else {
      const [, d, mes, a] = m;
      const fecha = new Date(Number(a), Number(mes) - 1, Number(d));
      const real =
        fecha.getFullYear() === Number(a) &&
        fecha.getMonth() === Number(mes) - 1 &&
        fecha.getDate() === Number(d);
      if (!real) errores.push("fecha-inexistente");
    }
  }

  if (parametros.importe !== undefined) {
    const valor = decodificar(parametros.importe);
    if (!/^\d{1,12}(\.\d{1,2})?$/.test(valor)) errores.push("importe-formato");
  }

  const valido = errores.length === 0;

  return {
    valido,
    errores,
    base: conocida.url,
    entorno: conocida.entorno,
    sistema: conocida.sistema,
    parametros,
    urlCorregida: valido ? null : corregir(conocida.url, parametros),
  };
}

/** Reconstruye la URL como debería haberse generado: codificando bien y con el punto decimal. */
function corregir(base: string, parametros: Record<string, string>): string | null {
  if (OBLIGATORIOS.some((n) => parametros[n] === undefined)) return null;

  const partes = OBLIGATORIOS.map((nombre) => {
    let valor = decodificar(parametros[nombre]);
    if (nombre === "importe") valor = valor.replace(",", ".");
    return `${nombre}=${encodeURIComponent(valor)}`;
  });

  return `${base}?${partes.join("&")}`;
}
