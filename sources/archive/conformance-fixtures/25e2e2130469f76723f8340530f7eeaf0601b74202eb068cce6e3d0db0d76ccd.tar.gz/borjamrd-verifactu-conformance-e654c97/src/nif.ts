/** Validación del NIF español (DNI, NIE y CIF), incluida la letra de control. */

const LETRAS_DNI = "TRWAGMYFPDXBNJZSQVHLCKE";
const LETRAS_CIF = "JABCDEFGHI";

/** Entidades cuyo dígito de control es SIEMPRE una letra. */
const CIF_CONTROL_LETRA = "KPQRSNW";
/** Entidades cuyo dígito de control es SIEMPRE un número. */
const CIF_CONTROL_DIGITO = "ABEH";

function letraDni(numero: number): string {
  return LETRAS_DNI[numero % 23];
}

export function nifValido(bruto: string): boolean {
  const nif = bruto.trim().toUpperCase();
  if (!/^[A-Z0-9]{9}$/.test(nif)) return false;

  // DNI: 8 dígitos + letra
  if (/^\d{8}[A-Z]$/.test(nif)) {
    return nif[8] === letraDni(Number(nif.slice(0, 8)));
  }

  // NIE: X/Y/Z + 7 dígitos + letra
  if (/^[XYZ]\d{7}[A-Z]$/.test(nif)) {
    const prefijo = "XYZ".indexOf(nif[0]);
    return nif[8] === letraDni(Number(`${prefijo}${nif.slice(1, 8)}`));
  }

  // CIF: letra + 7 dígitos + control (dígito o letra, según el tipo de entidad)
  if (/^[ABCDEFGHJKLMNPQRSUVW]\d{7}[0-9A-J]$/.test(nif)) {
    const digitos = nif.slice(1, 8);
    let suma = 0;

    for (let i = 0; i < 7; i++) {
      const d = Number(digitos[i]);
      if (i % 2 === 0) {
        // Posiciones impares (1.ª, 3.ª…): se duplican y se suman sus cifras.
        const doble = d * 2;
        suma += Math.floor(doble / 10) + (doble % 10);
      } else {
        suma += d;
      }
    }

    const control = (10 - (suma % 10)) % 10;
    const letra = LETRAS_CIF[control];
    const dado = nif[8];
    const inicial = nif[0];

    if (CIF_CONTROL_LETRA.includes(inicial)) return dado === letra;
    if (CIF_CONTROL_DIGITO.includes(inicial)) return dado === String(control);
    return dado === String(control) || dado === letra;
  }

  return false;
}
