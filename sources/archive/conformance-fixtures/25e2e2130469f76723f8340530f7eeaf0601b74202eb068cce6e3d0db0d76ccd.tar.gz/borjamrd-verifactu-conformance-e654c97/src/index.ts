import fixturesHuella from "../fixtures/huella.json" with { type: "json" };
import fixturesQr from "../fixtures/qr.json" with { type: "json" };

export * from "./huella";
export * from "./nif";
export * from "./qr";

/** De dónde sale el caso: un ejemplo literal de la AEAT, o derivado de una regla de la norma. */
export type Procedencia = "oficial" | "derivado";

export type CasoHuella = {
  id: string;
  procedencia: Procedencia;
  referencia: string;
  tipo: "alta" | "anulacion" | "evento";
  descripcion: string;
  campos: { nombre: string; valor: string }[];
  cadena: string;
  huella: string;
};

export type CasoQr = {
  id: string;
  procedencia: Procedencia;
  referencia: string;
  valido: boolean;
  descripcion?: string;
  url: string;
  errores?: string[];
  urlCorregida?: string;
};

/** Casos de prueba de la huella. Los tres son ejemplos oficiales de la AEAT. */
export const CASOS_HUELLA = fixturesHuella.casos as CasoHuella[];

/** Casos de prueba del QR. Ojo a `procedencia`: no todos son ejemplos literales de la AEAT. */
export const CASOS_QR = fixturesQr.casos as CasoQr[];

export const FIXTURES_HUELLA = fixturesHuella;
export const FIXTURES_QR = fixturesQr;
