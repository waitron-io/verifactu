/**
 * Cálculo de la huella (hash) de un registro de facturación Verifactu.
 *
 * Implementación de referencia. Sigue la especificación de la AEAT v0.1.2 y reproduce sus tres
 * vectores oficiales (ver `fixtures/huella.json` y los tests).
 */

export type TipoRegistro = "alta" | "anulacion" | "evento";

/** Un campo de la huella: nombre constante y valor ya recortado. */
export type Campo = { nombre: string; valor: string };

/**
 * Campos que entran en la huella, en el orden EXACTO en que se concatenan.
 *
 * Ojo con `evento`: el nombre `NIF` aparece dos veces (SistemaInformatico y ObligadoEmision). Por
 * eso los campos se modelan como lista ordenada y no como un mapa nombre→valor, que colapsaría el
 * duplicado y produciría una huella incorrecta.
 */
export const CAMPOS: Record<TipoRegistro, readonly string[]> = {
  alta: [
    "IDEmisorFactura",
    "NumSerieFactura",
    "FechaExpedicionFactura",
    "TipoFactura",
    "CuotaTotal",
    "ImporteTotal",
    "Huella",
    "FechaHoraHusoGenRegistro",
  ],
  anulacion: [
    "IDEmisorFacturaAnulada",
    "NumSerieFacturaAnulada",
    "FechaExpedicionFacturaAnulada",
    "Huella",
    "FechaHoraHusoGenRegistro",
  ],
  evento: [
    "NIF",
    "ID",
    "IdSistemaInformatico",
    "Version",
    "NumeroInstalacion",
    "NIF",
    "TipoEvento",
    "HuellaEvento",
    "FechaHoraHusoGenEvento",
  ],
} as const;

/** Campos numéricos, donde la norma admite una o dos posiciones decimales indistintamente. */
export const CAMPOS_NUMERICOS: Record<TipoRegistro, readonly string[]> = {
  alta: ["CuotaTotal", "ImporteTotal"],
  anulacion: [],
  evento: [],
} as const;

/** Concatena los campos en la cadena canónica `nombre=valor&nombre=valor&…`. */
export function cadenaCanonica(campos: Campo[]): string {
  return campos.map((c) => `${c.nombre}=${c.valor}`).join("&");
}

/** SHA-256 de la cadena en UTF-8, en hexadecimal y MAYÚSCULAS (64 caracteres). */
export async function sha256Hex(entrada: string): Promise<string> {
  const bytes = new TextEncoder().encode(entrada);
  const digest = await crypto.subtle.digest("SHA-256", bytes);

  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")
    .toUpperCase();
}

/** Calcula la huella de un registro a partir de sus campos, ya en orden. */
export async function calcularHuella(campos: Campo[]): Promise<string> {
  return sha256Hex(cadenaCanonica(campos));
}

/**
 * Formas decimales que la norma considera equivalentes para un mismo importe.
 *
 * "123.10" y "123.1" son el mismo valor y la AEAT acepta la huella calculada con cualquiera de
 * los dos, aunque produzcan hashes distintos. Un verificador que solo pruebe el literal del XML
 * dará falsos negativos.
 */
export function variantesDecimales(bruto: string): string[] {
  const valor = bruto.trim();
  const m = /^(-?\d+)(?:\.(\d*))?$/.exec(valor);
  if (!m) return [valor];

  const entero = m[1];
  const significativos = (m[2] ?? "").replace(/0+$/, "");
  const variantes = new Set<string>([valor]);

  if (significativos.length === 0) {
    variantes.add(entero);
    variantes.add(`${entero}.0`);
    variantes.add(`${entero}.00`);
  } else if (significativos.length === 1) {
    variantes.add(`${entero}.${significativos}`);
    variantes.add(`${entero}.${significativos}0`);
  } else {
    variantes.add(`${entero}.${significativos}`);
  }

  return [...variantes];
}

/**
 * Comprueba si una huella declarada es válida para unos campos dados, probando también las
 * variantes decimales que la norma admite.
 */
export async function verificarHuella(
  tipo: TipoRegistro,
  campos: Campo[],
  huellaDeclarada: string,
): Promise<{ valida: boolean; huellaCalculada: string; usoVarianteDecimal: boolean }> {
  const numericos = new Set(CAMPOS_NUMERICOS[tipo]);
  const declarada = huellaDeclarada.trim().toUpperCase();

  let combinaciones: Campo[][] = [[]];
  for (const campo of campos) {
    const valores = numericos.has(campo.nombre) ? variantesDecimales(campo.valor) : [campo.valor];
    combinaciones = combinaciones.flatMap((combo) =>
      valores.map((valor) => [...combo, { nombre: campo.nombre, valor }]),
    );
  }

  const literal = await calcularHuella(combinaciones[0]);
  if (literal === declarada) {
    return { valida: true, huellaCalculada: literal, usoVarianteDecimal: false };
  }

  for (const combo of combinaciones.slice(1)) {
    const hash = await calcularHuella(combo);
    if (hash === declarada) {
      return { valida: true, huellaCalculada: hash, usoVarianteDecimal: true };
    }
  }

  return { valida: false, huellaCalculada: literal, usoVarianteDecimal: false };
}
