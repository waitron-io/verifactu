import { describe, expect, it } from "vitest";

import fixturesHuella from "../fixtures/huella.json" with { type: "json" };
import fixturesQr from "../fixtures/qr.json" with { type: "json" };
import { CAMPOS, cadenaCanonica, calcularHuella, verificarHuella } from "../src/huella";
import { analizarQr } from "../src/qr";

/**
 * Esta suite hace dos cosas a la vez, y por eso vale:
 *
 *  1. Comprueba que la implementación de referencia cumple los fixtures.
 *  2. Comprueba que los fixtures son CORRECTOS: recalcula cada huella desde su cadena, en vez
 *     de fiarse del valor escrito en el JSON. Un carácter mal copiado no puede colarse.
 *
 * Si publicas fixtures equivocados, todas las librerías que los usen quedarán mal. Es lo único
 * que este repositorio no se puede permitir.
 */

describe("fixtures de la huella", () => {
  it.each(fixturesHuella.casos)("$id: la cadena canónica sale de sus campos", (caso) => {
    expect(cadenaCanonica(caso.campos)).toBe(caso.cadena);
  });

  it.each(fixturesHuella.casos)("$id: el SHA-256 de la cadena es la huella publicada", async (caso) => {
    expect(await calcularHuella(caso.campos)).toBe(caso.huella);
  });

  it.each(fixturesHuella.casos)("$id: los campos van en el orden que fija la norma", (caso) => {
    const tipo = caso.tipo as keyof typeof CAMPOS;
    expect(caso.campos.map((c) => c.nombre)).toEqual([...CAMPOS[tipo]]);
  });

  it.each(fixturesHuella.casos)("$id: la huella tiene el formato exigido", (caso) => {
    expect(caso.huella).toMatch(/^[0-9A-F]{64}$/);
  });

  it("los casos encadenan entre sí, que es de lo que va todo esto", () => {
    const [uno, dos, tres] = fixturesHuella.casos;
    const huellaAnterior = (caso: (typeof fixturesHuella.casos)[number]) =>
      caso.campos.find((c) => c.nombre === "Huella")?.valor;

    expect(huellaAnterior(uno)).toBe("");
    expect(huellaAnterior(dos)).toBe(uno.huella);
    expect(huellaAnterior(tres)).toBe(dos.huella);
  });

  it("verificarHuella acepta la huella correcta y rechaza una alterada", async () => {
    const caso = fixturesHuella.casos[0];

    expect((await verificarHuella("alta", caso.campos, caso.huella)).valida).toBe(true);
    expect((await verificarHuella("alta", caso.campos, "0".repeat(64))).valida).toBe(false);
  });

  it("una variante decimal equivalente sigue siendo válida", async () => {
    // El XML trae 123.450 en vez de 123.45: la norma admite ambas, y la huella oficial cuadra.
    const caso = fixturesHuella.casos[0];
    const campos = caso.campos.map((c) =>
      c.nombre === "ImporteTotal" ? { ...c, valor: "123.450" } : c,
    );

    const r = await verificarHuella("alta", campos, caso.huella);

    expect(r.valida).toBe(true);
    expect(r.usoVarianteDecimal).toBe(true);
  });
});

describe("fixtures del QR", () => {
  const validos = fixturesQr.casos.filter((c) => c.valido);
  const invalidos = fixturesQr.casos.filter((c) => !c.valido);

  it.each(validos)("$id: se acepta", (caso) => {
    const r = analizarQr(caso.url);

    expect(r.errores).toEqual([]);
    expect(r.valido).toBe(true);
  });

  it.each(invalidos)("$id: se rechaza, con los errores esperados", (caso) => {
    const r = analizarQr(caso.url);

    expect(r.valido).toBe(false);
    for (const esperado of caso.errores ?? []) {
      expect(r.errores).toContain(esperado);
    }
  });

  it.each(invalidos.filter((c) => "urlCorregida" in c))(
    "$id: propone la URL corregida",
    (caso) => {
      expect(analizarQr(caso.url).urlCorregida).toBe(caso.urlCorregida);
    },
  );

  it("la URL corregida del «&» sin codificar es a su vez válida", () => {
    const roto = fixturesQr.casos.find((c) => c.id === "ampersand-sin-codificar")!;
    const corregida = analizarQr(roto.url).urlCorregida!;

    expect(analizarQr(corregida).valido).toBe(true);
  });
});

describe("honestidad de los fixtures", () => {
  it("todo caso declara si es un ejemplo oficial de la AEAT o derivado de una regla", () => {
    for (const caso of [...fixturesHuella.casos, ...fixturesQr.casos]) {
      expect(["oficial", "derivado"]).toContain(caso.procedencia);
      expect(caso.referencia).not.toBe("");
    }
  });

  it("los tres casos de la huella son oficiales: no nos inventamos ninguno", () => {
    expect(fixturesHuella.casos.every((c) => c.procedencia === "oficial")).toBe(true);
  });
});
